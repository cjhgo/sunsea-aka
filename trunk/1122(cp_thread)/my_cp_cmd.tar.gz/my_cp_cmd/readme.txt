程序功能：
	模仿linux_os本身cp命令
	linux_os:	cp test_old.txt test_new.txt
	my_program:	./my_cp test_old.txt test_new.txt

	注：该程序默认创建5个线程复制

说明：
	1、编译
		make

	2、运行
		./my_cp test_old.txt test_new.txt
		
		运行结果是，把test_old.txt复制到test_new.txt
